        Read Me First

This archive contains example code and sample solutions for the exercises in the book "Essential Algorithms: A Practical Approach to Computer Algorithms" by Rod Stephens, 2013, John Wiley & Sons, Inc. For more information about the book, go to:

        http://www.wiley.com/go/essentialalgorithms

Notes:

        - Chapters 13 and 14 both have versions of the NetworkMaker example program. The version included in Chapter 14 does everything the other version does plus it includes new tools to demonstrate techniques described in Chapter 14.

        - Chapters 11 and 17 through 19 do not have any code.
