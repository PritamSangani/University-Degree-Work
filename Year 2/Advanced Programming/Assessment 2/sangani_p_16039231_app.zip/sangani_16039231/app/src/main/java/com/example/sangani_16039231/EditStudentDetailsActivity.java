package com.example.sangani_16039231;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.Gson;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class EditStudentDetailsActivity extends AppCompatActivity {
    final String TAG = "EditStudentDetails";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student_details);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        Bundle extras = getIntent().getExtras();
        final Student stu = (Student) extras.get("student");

        //get instances of all views in activity
        final EditText name = findViewById(R.id.nameEditText);
        final RadioGroup genderGroup = findViewById(R.id.genderRadioGroup);
        final RadioButton maleButton = findViewById(R.id.maleRadioButton);
        final RadioButton femaleButton = findViewById(R.id.femaleRadioButton);
        final EditText dob = findViewById(R.id.dateOfBirthEditText);
        final EditText address = findViewById(R.id.addressEditText);
        final EditText postcode = findViewById(R.id.postcodeEditText);
        final EditText studentNumber = findViewById(R.id.studentNumberEditText);
        final EditText courseTitle = findViewById(R.id.courseTitleEditText);
        final EditText startDate = findViewById(R.id.startDateEditText);
        final EditText bursary = findViewById(R.id.bursaryEditText);
        final EditText email = findViewById(R.id.emailEditText);

        final Button editStudentButton = findViewById(R.id.editStudentDetailsButton);

        name.setText(stu.getName());
        if(stu.getGender().equals("M"))
            genderGroup.check(R.id.maleRadioButton);
        else if (stu.getGender().equals("F"))
            genderGroup.check(R.id.femaleRadioButton);
        dob.setText(stu.getDob());
        address.setText(stu.getAddress());
        postcode.setText(stu.getPostcode());
        studentNumber.setText(String.format(Locale.ENGLISH,"%d",stu.getStudentNumber()));
        courseTitle.setText(stu.getCourseTitle());
        startDate.setText(stu.getStartDate());
        bursary.setText(String.format(Locale.ENGLISH, "%f", stu.getBursary()));
        email.setText(stu.getEmail());

        //make the studentNumber EditText field readonly as it cannot be changed
        studentNumber.setEnabled(false);

        editStudentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String gender;
                if(genderGroup.getCheckedRadioButtonId() == maleButton.getId())
                    gender = "M";
                else if(genderGroup.getCheckedRadioButtonId() == femaleButton.getId())
                    gender = "F";
                else
                    gender = "U";

                Student stu = new Student(name.getText().toString(), gender, dob.getText().toString(), address.getText().toString(), postcode.getText().toString(), Integer.parseInt(studentNumber.getText().toString()), courseTitle.getText().toString(), startDate.getText().toString(), Float.parseFloat(bursary.getText().toString()), email.getText().toString());
                Log.d(TAG, stu.getName());
                editStudent(stu);
            }
        });
    }

    private void editStudent(Student stu) {
        new EditStudentDetailsActivity.UpdateStudentTask().execute(stu);
    }

    private class UpdateStudentTask extends AsyncTask<Student,Void,Void> {
        URL url;
        final String TAG = "EditStudentTask";


        @Override
        protected Void doInBackground(Student... students) {
            Student stu = students[0];
            Gson gson = new Gson();
            HashMap<String, String> postDataParams = new HashMap<>();
            final String API_KEY = "31d1b82668";

            //convert student object to json
            String json = gson.toJson(stu);

            //add post parameters to hashmap
            postDataParams.put("apikey", API_KEY);
            postDataParams.put("json", json);

            try {
                url = new URL("http://radikaldesign.co.uk/sandbox/studentapi/update.php");

                Log.d(TAG, postDataParams.get("json"));

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);

                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                DataOutputStream stream = new DataOutputStream(conn.getOutputStream());
                stream.writeBytes(getPostDataString(postDataParams));
                stream.flush();
                stream.close();

                int responseCode = conn.getResponseCode();

                Log.d(TAG, Integer.toString(responseCode));

            } catch (IOException e) {
                Log.d(TAG, e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }

        private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()) {
                if(first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }
    }

}
