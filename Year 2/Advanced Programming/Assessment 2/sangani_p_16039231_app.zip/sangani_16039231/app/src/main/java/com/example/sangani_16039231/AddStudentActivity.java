package com.example.sangani_16039231;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.Gson;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Activity that allows a user to add a Student to the database.
 */
public class AddStudentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final String TAG = "AddStudentActivity";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        //Don't display soft keyboard when activity has started
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        View view = findViewById(R.id.addStudentText);

        Snackbar.make(view, "Enter all details of new Student", Snackbar.LENGTH_LONG).show();

        //retrieve instances of all text fields
        final EditText name = findViewById(R.id.nameEditText);
        final RadioGroup genderGroup = findViewById(R.id.genderRadioGroup);
        final RadioButton maleButton = findViewById(R.id.maleRadioButton);
        final RadioButton femaleButton = findViewById(R.id.femaleRadioButton);
        final EditText dob = findViewById(R.id.dateOfBirthEditText);
        final EditText address = findViewById(R.id.addressEditText);
        final EditText postcode = findViewById(R.id.postcodeEditText);
        final EditText studentNumber = findViewById(R.id.studentNumberEditText);
        final EditText courseTitle = findViewById(R.id.courseTitleEditText);
        final EditText startDate = findViewById(R.id.startDateEditText);
        final EditText bursary = findViewById(R.id.bursaryEditText);
        final EditText email = findViewById(R.id.emailEditText);

        Button addStudentButton = findViewById(R.id.addStudentButton);

        addStudentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String gender;
                //get the gender radio button that is selected in the radiogroup and the parse the value to a String
                if(genderGroup.getCheckedRadioButtonId() == maleButton.getId())
                    gender = "M";
                else if(genderGroup.getCheckedRadioButtonId() == femaleButton.getId())
                    gender = "F";
                else
                    gender = "U";

                Student stu = new Student(name.getText().toString(), gender, dob.getText().toString(), address.getText().toString(), postcode.getText().toString(), Integer.parseInt(studentNumber.getText().toString()), courseTitle.getText().toString(), startDate.getText().toString(), Float.parseFloat(bursary.getText().toString()), email.getText().toString());
                Log.d(TAG, stu.getName());
                addStudent(stu);
            }
        });
    }

    //method that calls the AsyncTask which creates the network call to add a Student to the database
    private void addStudent(Student stu) {
        new AddStudentTask().execute(stu);
    }


    private class AddStudentTask extends AsyncTask<Student,Void,Void> {
        URL url;

        @Override
        protected Void doInBackground(Student... students) {
            Student stu = students[0];
            Gson gson = new Gson();
            HashMap<String, String> postDataParams = new HashMap<>();
            final String API_KEY = "31d1b82668";
            final String TAG = "AddStudentTask";
            //convert student object to json
            String json = gson.toJson(stu);

            //add post parameters to hashmap
            postDataParams.put("apikey", API_KEY);
            postDataParams.put("json", json);

            try {
                url = new URL("http://radikaldesign.co.uk/sandbox/studentapi/add.php");

                Log.d(TAG, postDataParams.get("json"));

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);

                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                DataOutputStream stream = new DataOutputStream(conn.getOutputStream());
                stream.writeBytes(getPostDataString(postDataParams));
                stream.flush();
                stream.close();

                int responseCode = conn.getResponseCode();

                Log.d(TAG, Integer.toString(responseCode));

            } catch (IOException e) {
                Log.d(TAG, e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }

        private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()) {
                if(first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }
    }


}
