package com.example.sangani_16039231;

import android.support.v7.widget.RecyclerView;

/**
 * Created by Pritam Sangani on 27/03/2018.
 */

public interface RecyclerItemTouchHelperListener {
    void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position);
}
