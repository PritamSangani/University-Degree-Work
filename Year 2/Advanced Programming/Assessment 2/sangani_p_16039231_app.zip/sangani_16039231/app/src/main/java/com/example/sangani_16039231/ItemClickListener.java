package com.example.sangani_16039231;

/**
 * Created by Pritam Sangani on 04/03/2018.
 */

/**
 * Interface used by the StudentsListAdapter that handles what happens when an item in the list is pressed
 */
public interface ItemClickListener {
    void onItemClick(Student stu);
}
