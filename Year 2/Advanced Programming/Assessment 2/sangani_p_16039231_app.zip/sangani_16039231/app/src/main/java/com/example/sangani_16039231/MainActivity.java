package com.example.sangani_16039231;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 *  Launcher activity that the users sees first when opening the app.
 *  Contains functionality to view all Students in the database and
 *  delete a Student from the database by means of swiping the Student list item from the Recycler View list.
 *
 *  Two AsyncTasks are used to make the network calls to the Student RESTful API hosted at:
 *  'http://radikaldesign.co.uk/sandbox/studentapi/index.php'
 */

public class MainActivity extends AppCompatActivity implements RecyclerItemTouchHelperListener {
    //TAG for Debugging Purposes
    private final String TAG = "MainActivity";
    public StudentsListAdapter adapter;
    RecyclerView studentsList;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        studentsList = findViewById(R.id.recyclerView);
        fab = findViewById(R.id.fab);

        getAllStudents();
        initSwipeCallback();
        initFab();
    }

    //method containing the call to the AsyncTask which calls the API to retrieve all the Students in the database.
    private void getAllStudents() {
        final String API_KEY = "31d1b82668";
        String url = "http://radikaldesign.co.uk/sandbox/studentapi/getallstudents.php?apikey="+ API_KEY;
        new GetAllStudentsTask().execute(url);
    }

    //method containing the code to initialise the Floating Action Button - which sends the user to the AddStudentActivity when pressed
    private void initFab() {
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //set up an intent to start the AddStudentActivity when onClick method is called
                Intent intent = new Intent(getApplicationContext(), AddStudentActivity.class);
                startActivity(intent);
            }
        });
    }

    //method to initialise the callback helper function to enable the swiping of items in the list.
    // - uses the RecyclerItemTouchHelper class
    private void initSwipeCallback() {
        ItemTouchHelper.SimpleCallback simpleCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);

        //attach the ItemTouchHelper callback function to the studentsList RecyclerView
        new ItemTouchHelper(simpleCallback).attachToRecyclerView(studentsList);
    }

    //override the onSwiped method to define the response when the method is called.
    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, final int position) {
        //get the Student object at the position of the adapter.
        final Student stu = adapter.getStudent(position);
        Log.d(TAG, "Swiped: "+stu.getName());

        //build an AlertDialog to get a confirmation from the user that they want to delete a Student
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);

        alertDialog.setMessage(Html.fromHtml("Are you sure you want to remove " + "<b>" + stu.getName() + "</b>" + " from the database?"))
                .setCancelable(false)
                //if the user presses "YES" -> call the AsyncTask to create the network call to the API to delete the Student from the databse
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int studentNumber = stu.getStudentNumber();

                        new DeleteStudentTask().execute(position,studentNumber);
                    }
                })
                //if the user presses "NO" then do nothing
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        adapter.notifyDataSetChanged();
                    }
                });

        AlertDialog aDialog = alertDialog.create();
        aDialog.setTitle("Confirm Deletion of Student");
        aDialog.show();
    }

    //AsyncTask class that contains the code to create the network call to retrieve all Students from the database.
    @SuppressLint("StaticFieldLeak")
    private class GetAllStudentsTask extends AsyncTask<String,Void,ArrayList<Student>> {
        private final String TAG = "GetAllStudentsTask";

        //method that executes network call
        @Override
        protected ArrayList<Student> doInBackground(String... urls) {
            URL url;
            HttpURLConnection urlConnection;
            InputStream in = null;
            String response;
            Gson gson = new Gson();
            ArrayList<Student> students;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                in = new BufferedInputStream(urlConnection.getInputStream());
            } catch (IOException e) {
                Log.d(TAG, e.getMessage());
            }
            //converts the inputstream object to a String
            response = convertStreamToString(in);
            //get the class/type of the ArrayList - needed to parse the json array straight into an ArrayList of Student objects
            Type listType = new TypeToken<ArrayList<Student>>() {}.getType();

            students = gson.fromJson(response, listType);

            Log.d(TAG, "AL Size: "+students.size());
            return students;
        }

        //method that handles what happens after the network call has been executed
        @Override
        protected void onPostExecute(ArrayList<Student> studentArrayList) {
            super.onPostExecute(studentArrayList);
            initAdapter(studentArrayList);
            initRecyclerView();
        }

        //method that initialises the Adapter - used to display data in the Recycler View
        private void initAdapter(final ArrayList<Student> studentArrayList) {
            adapter = new StudentsListAdapter(getApplicationContext(), studentArrayList, new ItemClickListener() {
                @Override
                public void onItemClick(Student stu) {
                    int position = studentArrayList.indexOf(stu);

                    Log.d(TAG, "Item Clicked: " + position + " Student: " + stu.getName());
                    Toast.makeText(getApplicationContext(), "You selected " + stu.getName(), Toast.LENGTH_LONG).show();
                    goToStudentDetailsActivity(studentArrayList, position);
                }
            });
        }

        //method that initialises the RecyclerView
        private void initRecyclerView() {
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            studentsList.setLayoutManager(mLayoutManager);
            studentsList.setItemAnimator(new DefaultItemAnimator());
            studentsList.addItemDecoration(new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL));
            studentsList.setAdapter(adapter);
        }

        //method that when called sends the user from this Activity to the StudentDetailsActivity
        // - sending across the Student object with the intent
        private void goToStudentDetailsActivity(ArrayList<Student> studentArrayList, int position) {
            Intent intent = new Intent(getApplicationContext(), StudentDetailsActivity.class);
            intent.putExtra("student", studentArrayList.get(position));
            startActivity(intent);
        }

        //method to convert an InputStream into a String
        private String convertStreamToString(InputStream is) {
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
    }

    //AsyncTask class that contains the code to create the network call to delete an individual Student from the database
    @SuppressLint("StaticFieldLeak")
    private class DeleteStudentTask extends AsyncTask<Integer,Void,Void> {
        URL url;
        final String TAG = "EditStudentTask";
        int position;
        @Override
        protected Void doInBackground(Integer... studentNumbers) {
            int stuNumber = studentNumbers[1];
            position = studentNumbers[0];
            HashMap<String, String> postDataParams = new HashMap<>();
            final String API_KEY = "31d1b82668";

            //add post parameters to hashmap
            postDataParams.put("apikey", API_KEY);
            postDataParams.put("studentnumber", String.format(Locale.ENGLISH, "%d", stuNumber));

            try {
                url = new URL("http://radikaldesign.co.uk/sandbox/studentapi/delete.php");

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);

                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                DataOutputStream stream = new DataOutputStream(conn.getOutputStream());
                stream.writeBytes(getPostDataString(postDataParams));
                stream.flush();
                stream.close();

                int responseCode = conn.getResponseCode();

                Log.d(TAG, Integer.toString(responseCode));

            } catch (IOException e) {
                Log.d(TAG, e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.deleteStudent(position);
            //tell the adapter that the DataSet has been changed so it refreshes to display the remaining Students in the database
            adapter.notifyDataSetChanged();
        }

        //method to parse the parameters(in the HashMap) to a string so they can be sent in the POST request.
        private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()) {
                if(first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }
    }
}
