package com.example.sangani_16039231;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * Custom Adapter which is used to display each Student item in the List in the Main Activity
 */
public class StudentsListAdapter extends RecyclerView.Adapter<StudentsListAdapter.MyViewHolder> {
    private static final String TAG = "StudentsListAdapter";
    private ArrayList<Student> mDataSet;
    Context mContext;
    ItemClickListener listener;

    public StudentsListAdapter(Context mContext, ArrayList<Student> studentArrayList, ItemClickListener listener) {
        this.mContext = mContext;
        mDataSet = studentArrayList;
        this.listener = listener;
    }

    @Override
    public StudentsListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_list_item, parent, false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(StudentsListAdapter.MyViewHolder holder, int position) {
        Log.d(TAG, "Element "+position+" set.");
        holder.bind(mDataSet.get(position), listener);
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    public Student getStudent(int position) {
        return mDataSet.get(position);
    }

    public void deleteStudent(int position) {
        mDataSet.remove(position);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView name, email;
        private final ImageView gender;
        public RelativeLayout viewBackground, viewForeground;

        public MyViewHolder(View view) {
            super(view);

            name = view.findViewById(R.id.name);
            email = view.findViewById(R.id.email);
            gender = view.findViewById(R.id.genderImage);
            viewBackground = view.findViewById(R.id.item_background);
            viewForeground = view.findViewById(R.id.item_foreground);
        }

        public void bind(final Student stu, final ItemClickListener listener) {
            name.setText(stu.getName());
            email.setText(stu.getEmail());

            if(stu.getGender().equals("M")) {
                gender.setImageResource(R.drawable.ic_male_icon);
            } else {
                gender.setImageResource(R.drawable.ic_female_icon);
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(stu);
                }
            });
        }
    }
}

